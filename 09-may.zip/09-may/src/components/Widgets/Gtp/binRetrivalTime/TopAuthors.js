//Top Authors widget

import React, { Component } from 'react'
import {Button, ButtonGroup, Carousel} from 'react-bootstrap'
import Spline from './Spline';

const bins = [
	   {
	      id: 1,
	      name: "Overall"
	   },
	   {
		      id: 2,
		      name: "Picking"
	   },
	   {
	      id: 3,
	      name: "Consolidation"
	   },
	   {
	      id: 4,
	      name: "Decanting"
	   },
	   {
	      id: 5,
	      name: "Cycle Count"
	   }
	]

export default class TopAuthors extends Component {
   render() {
	   
	   let opt = {
				data: [[0, 0,  0, 0, 0, 0,15, 25, 30, 15, 0, 0 ]],
				colors: ['#7B43A1'],
				labels: ['Bins'],
				axis: [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65],
				targetvalue:6,
				currentposition:8
			
		}
	   
      const settings = {
			   interval: null,
			   indicators: false,
			   //nextIcon: <span aria-hidden='true' className='icon-arrow-left' />,
			   //prevIcon: <span aria-hidden='true' className='carousel-control-next-icon' />
	   };
      //console.log(asd)
      return (
    		  
    		  <div>
    		  	<div>
    		  		<h4 className="title">Bin-Retrieval Time</h4>
    		  	<div className="clearfix" >
    		  		<ButtonGroup className="btn-group dayweek">
    		  			<Button style={{zIndex: "0"}} key={1} className="active btn-primry" variant="light">DAY</Button>
    		  			<Button style={{zIndex: "0"}} key={2} variant="light">WEEK</Button>
    		  		</ButtonGroup>
	    		</div>
	    		  <div className="author-detail-wrap d-flex justify-content-between flex-column">
		    		  <Carousel {...settings}>
			    		  {bins && bins.map((bin, key) => (
		    				  <Carousel.Item key={bin.id}>
			    				  <div className="author-avatar overlay-wrap mb-5">
		    				  	  <div className="avatar-img">
		    				  		<h5 className="title">{bin.name}</h5>
		    				  	  </div>
		    				  	  <div className="authors-info text-center">
		    				  			<Spline opt={opt} />
		    				  	   </div>	
		    				  	</div>
		    				  </Carousel.Item>
			    		  ))}
		    		  </Carousel> 
	    		  </div>
	    		</div>
    		  </div>
      )
   }
}
