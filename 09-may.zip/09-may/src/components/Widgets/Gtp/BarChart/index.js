import React, { Component } from 'react';
import { connect } from 'react-redux';  // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component
import PropTypes from 'prop-types';
import BarChart from 'react-bar-chart';

const margin = {top: 0, right: 0, bottom: 0, left: 40};

class StationStatusBar extends Component {

	constructor(props) {
		super(props);
		this.state = { 
			colors: ['#2D5FD9', '#FFFFFF']
		};
	}
	
  render() {
  
	let data1 = [
	  {text: 'Man', value: 2000, backgroundColor: '#2D5FD9'} 
	];
	
	let data2 = [
	  {text: 'Woman', value: 300} 
	];

	let activeWidth = 100;
	let inActiveWidth = 30;
	
	let scale = value => { 
		// some color selection
		return '#2D5FD9';
	};
	
    return (
        <div className="mainCustomBar">
				              
				<div className="leftBar" >
					<BarChart 
						//ylabel='Quantity'
						width={10}
						height={60}
						data={data1}
						color= "red"
					/>
				</div>
				<div className="customLine" >&nbsp;</div>
				<div className="rightBar" >
					<BarChart 
					  //ylabel='Quantity'
					  width={10}
					  height={36}
					  data={data2}
					  colors={ '#FFFFFF' }
					/>
				</div>
        </div>
    );
  }
}

export default StationStatusBar;
