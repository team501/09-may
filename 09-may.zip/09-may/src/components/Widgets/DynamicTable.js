import React, { Component } from 'react';

// intl messages
import IntlMessages from 'Util/IntlMessages';
import NumberClass, { NumberFormatter } from 'Util/NumberClass';


//Bootstrap datatable custom 
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import ToolkitProvider, { Search } from 'react-bootstrap-table2-toolkit';


class DynamicTable extends Component {
    
}