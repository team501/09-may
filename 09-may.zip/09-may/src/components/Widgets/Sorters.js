/**
 * Sorter
 */
import React, { Component } from 'react';

//json
import json from 'JsnCnfg/MngEqpmnt/UntSrtrMnDshbrd/sorterJson.json';
import { connect } from 'react-redux';  // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component 

// intl messages
import IntlMessages from 'Util/IntlMessages';

// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart'
//chart config
import ChartConfig from 'Constants/chart-config';

import {Link} from 'react-router-dom';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import { graphQlURLPrd } from '../../services/Config.js';
import CircularProgressbar from 'react-circular-progressbar';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';
import { ProgressBar } from 'react-bootstrap';
import Grid from '@material-ui/core/Grid';
import NumberClass from 'Util/NumberClass';

import Spinner from 'Util/Spinner';

const headingGrid = {
		textAlign: 'left',
		height: '25px',
		fontSize: 'large',
		padding: '5px'
};

const headingGrid2 = {
		textAlign: 'left',
		height: '25px',
	    fontSize: 'medium',
		padding: '5px 5px 30px 5px'
};

const headingGrid3 = {
		height: '25px',
	    fontSize: 'medium',
		padding: '5px'
};

const bottomGrid = {
		textAlign: 'left',
		height: '25px',
	    fontSize: 'xx-large',
		padding: '5px'
};

const mainGrid = {
		padding: '25px',
		height: '170px',
};

const gridContent = {
		height: '40px',
		padding: '0px',
		fontSize: 'xx-large'	
};

class Sorters extends Component {

	constructor(props) {
		super(props);
		this.startTime = 201903230547;//dateFormat(new Date(), "yyyymmddHHMM");
		this.state = {	sorterId:[],
						inducts: [],
						sorts: [],
						chuteDetails: [],
					    isLoading:true
					 };
	}

	sorterDetailsQuery = {
		sorterDetailsQuery_Inducts: json.container.leftSegment.components[0].options.query,
		sorterDetailsQuery_Sorts: json.container.leftSegment.components[1].options.query,
		sorterDetailsQuery_Chute: json.container.leftSegment.components[2].options.query,
		sorterDetailsQuery_SorterId: json.container.leftSegment.components[3].options.query
	}
	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getSorterId();
		this.getInducts();
		this.getSorts();
		this.getChuteDetails();
	}

	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.startTime = 201903230547;//dateFormat(new Date(), "yyyymmddHHMM");
			this.getSorterId();
			this.getInducts();
			this.getSorts();
			this.getChuteDetails();
		}
	}

	// recent orders
	getSorterId() {
		let query = this.sorterDetailsQuery.sorterDetailsQuery_SorterId;
		
		let startTime = this.startTime;
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', },
											   body: JSON.stringify({ query, variables: { startTime } })
		}).then(r => r.json())
		.then(data => { 
		    this.setState({ sorterId: data.data.getUnitSorterDetails !== undefined && data.data.getUnitSorterDetails !== null ? data.data.getUnitSorterDetails : new Array(),
						    isLoading:false
						  }); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ sorterId: [],
						    isLoading:false
						  }); 
		});
	}
	
	getInducts() {
		let query = this.sorterDetailsQuery.sorterDetailsQuery_Inducts;
		
		let startTime = this.startTime;
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', },
											   body: JSON.stringify({ query, variables: { startTime } })
		}).then(r => r.json())
		.then(data => { 
		    this.setState({ inducts: data.data.getUnitSorterDetails !== undefined && data.data.getUnitSorterDetails !== null ? data.data.getUnitSorterDetails : new Array(),
						    isLoading:false
						  }); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ inducts: [],
						    isLoading:false
						  }); 
		});
	}
	
	getSorts() {
		let query = this.sorterDetailsQuery.sorterDetailsQuery_Sorts;
		
		let startTime = this.startTime;
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', },
											   body: JSON.stringify({ query, variables: { startTime } })
		}).then(r => r.json())
		.then(data => { 
		    this.setState({ sorts: data.data.getUnitSorterDetails !== undefined && data.data.getUnitSorterDetails !== null ? data.data.getUnitSorterDetails : new Array(),
						    isLoading:false
						  }); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ sorts: [],
						    isLoading:false
						  }); 
		});
	}
	
	getChuteDetails() {
		let query = this.sorterDetailsQuery.sorterDetailsQuery_Chute;
		
		let startTime = this.startTime;
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', },
											   body: JSON.stringify({ query, variables: { startTime } })
		}).then(r => r.json())
		.then(data => { 
		    this.setState({ chuteDetails: data.data.getUnitSorterDetails !== undefined && data.data.getUnitSorterDetails !== null ? data.data.getUnitSorterDetails : new Array(),
						    isLoading:false
						  }); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ chuteDetails: [],
						    isLoading:false
						  }); 
		});
	}

	setBarColor = (percentage) => {
		if(percentage < 30) {
			return "danger";
		} else if(percentage >= 30 && percentage <=80) {
			return "warning";
		} else if(percentage > 80) {
			return "success";
		}
	} 

	render() {
	
	
	let inductsTitle = json.container.leftSegment.components[0].options.title;
	let sortsTitle = json.container.leftSegment.components[1].options.title;
	let chuteTitle = json.container.leftSegment.components[2].options.title;
	let fullTitle = json.container.leftSegment.components[2].options.full;
	let assignedTitle = json.container.leftSegment.components[2].options.assigned;
	
	const { isColorBlind } = this.props;
		const sorters = (data) => {
			
			let inductGoal = 1;
			let sortGoal = 1;
			let inductsFromService = 1;
			let sortsFromService = 1;
			let chuteAssignedPercent = 1;
			let fullCount = 1;
			
			let inducts = this.state.inducts != null && this.state.inducts != undefined ? this.state.inducts : new Array();
			inducts.filter(element => data.sorterId == element.sorterId).map(element => {
				inductsFromService = element.inducts;
				return element;
			});
			this.props.goal.filter(element => data.sorterId == element.name).map(element => {
				inductGoal = element.inductGoalPerHour;
				return element;
			});
			

			let sorts = this.state.sorts != null && this.state.sorts != undefined ? this.state.sorts : new Array();
			sorts.filter(element => data.sorterId == element.sorterId).map(element => {
				sortsFromService = element.sorts;
				return element;
			});
			this.props.goal.filter(element => data.sorterId == element.name).map(element => {
				sortGoal = element.sortsGoalPerHour;
				return element;
			});
			
			let chuteDetails = this.state.chuteDetails != null && this.state.chuteDetails != undefined ? this.state.chuteDetails : new Array();
			chuteDetails.filter(element => data.sorterId == element.sorterId).map(element => {
				chuteAssignedPercent = element.assignedPercent;
				fullCount = element.fullCount;
				return element;
			});
			
			
			
			let inductPercentage = parseInt((inductsFromService/inductGoal) * 100) ;
			let sortsPercentage = parseInt((sortsFromService/sortGoal) * 100);
			
			console.log("=---------------------------------------=");
			console.log(inductGoal+","+sortGoal);
			console.log("=---------------------------------------=");
			return (
					<RctCollapsibleCard
					colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full sorter-height"
					heading={data.sorterId}
					key={data.sorterId}
					fullBlock
					>
						<div className="clearfix">
		                <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 float-left">  
		      
		                <Grid container>
						<Grid style={mainGrid} container spacing={24}>
							<Grid item xs={4} sm={4}>
							<Grid style={headingGrid2} item xs={12} sm={12}>
								{<IntlMessages id="unitsorterDashbrd.sorters.indusctFrLstHr" />}
							</Grid>
								<Grid style={headingGrid2} item xs={12} sm={12}>
								
									{isColorBlind ? (
										<div className="unisorter_blind">
									<ProgressBar style={{height: '5px'}} bsStyle={this.setBarColor(inductPercentage)} now={inductPercentage} />
									</div>
									  ) : (
										<ProgressBar style={{height: '5px'}} bsStyle={this.setBarColor(inductPercentage)} now={inductPercentage} />
									  )}
									</Grid>
								
								<Grid style={bottomGrid} item xs={12} sm={12}>
									<NumberClass  number= {inductsFromService} />
								</Grid>
							</Grid>
							
							<Grid item xs={4} sm={4}>
								<Grid style={headingGrid2} item xs={12} sm={12}>
									{<IntlMessages id="unitsorterDashbrd.sorters.sortsFrLstHr" />}
								</Grid>
							
								<Grid style={headingGrid2} item xs={12} sm={12}>
									{isColorBlind ? (
										<div className="unisorter_blind">
									<ProgressBar style={{height: '5px'}} bsStyle={this.setBarColor(sortsPercentage)} now={sortsPercentage} />
									</div>
									  ) : (
										<ProgressBar style={{height: '5px'}} bsStyle={this.setBarColor(sortsPercentage)} now={sortsPercentage} />
									  )}
								</Grid>
						
								<Grid style={bottomGrid} item xs={12} sm={12}>
									<NumberClass  number= {sortsFromService} />
								</Grid>
							</Grid>
						
							<Grid item xs={4} sm={4} >
								<Grid style={headingGrid2} item xs={12} sm={12}>
									<div style={{float: 'left'}}>{<IntlMessages id="unitsorterDashbrd.sorters.chuteStatus" />}</div>
									
								</Grid>
								
								<Grid container spacing={24}>
									<Grid item xs={12} sm={6} style={{textAlign: 'left'}}>
										<Grid style={gridContent} item xs={12} sm={12}>
											{chuteAssignedPercent}%
										</Grid>
										<Grid style={headingGrid3} item xs={12} sm={12}>
											{<IntlMessages id="unitsorterDashbrd.sorters.assigned" />}
										</Grid>
									</Grid>
									<Grid item xs={12} sm={4} style={{textAlign: 'left'}}>
										<Grid style={gridContent} item xs={12} sm={12}>
											<NumberClass  number= {fullCount} />
										</Grid>
										<Grid style={headingGrid3} item xs={12} sm={12}>
											{<IntlMessages id="unitsorterDashbrd.sorters.full" />}
										</Grid>
									</Grid>
									<Grid item xs={12} sm={2} className="right-arrow">
										<Link to={{ pathname: `/app/dashboard/sorterDetails/${data.sorterId}`}}> &#x203A; </Link>
									</Grid>
									
								</Grid>
								
							</Grid>
							

							
						</Grid>	
					</Grid>
		           </div>
		            </div>
		        </RctCollapsibleCard>
			);
		}

		if(this.state.isLoading){
			return (<RctCollapsibleCard	colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
										heading={""}
										fullBlock > 
					</RctCollapsibleCard>);
		} else {
			return ( <React.Fragment>
						{ this.state.sorterId.map(data => sorters(data) ) }
					</React.Fragment> );
		}
		
	}
}


// map state to props
// Here we can fetch the value of isColorBlind as props
const mapStateToProps = ({ settings }) => {
	const { isColorBlind ,locale} = settings;
	return { isColorBlind,locale };
};


export default withRouter(connect(mapStateToProps)(Sorters));
