/**
 * InductsForTheDay
 */
import React, { Component } from 'react';

import { connect } from 'react-redux'; // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component 

//json
import json from 'JsnCnfg/MngEqpmnt/UntSrtrMnDshbrd/sortsForTheDayJson.json';

// intl messages
import IntlMessages from 'Util/IntlMessages';

// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';
//chart config
import ChartConfig from 'Constants/chart-config';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import {graphQlURLPrd} from '../../services/Config.js';
import CircularProgressbar from 'react-circular-progressbar';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';
import NumberClass from 'Util/NumberClass';

import Spinner from 'Util/Spinner';

class SortsForTheDay extends Component {

	constructor(props) {
		super(props);
		this.startTime = 201903230547;//dateFormat(new Date(), "yyyymmddHHMM");
		this.goalVal = this.props.goal;
		this.sorterid = this.props.sorterid;
		this.state = { 
					   label: [],
					   value: [],
					   sorts: 0,
					   sortsPercent: 0,
					   isLoading:true
					 };
	}

	sortsForTheDay = {
		sortsForTheDay_CurrentValue: json.container.rightSegment.components[0].options.query,
		sortsForTheDay_CurrentPercentage: json.container.leftSegment.components[0].options.query,
		sortsForTheDay_LastHours: json.container.rightSegment.components[1].options.query
	}
	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getCurrentValue();
		this.getCurrentPercentage();
		this.getlastArray();
	}

	//Comparing props and triggering refresh 
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.startTime = 201903230547;//dateFormat(new Date(), "yyyymmddHHMM");
			this.getCurrentValue();
			this.getCurrentPercentage();
			this.getlastArray();
		}
	}

	getCurrentValue() {
		let startTime = this.startTime;
		let goalVal = this.goalVal;
		let sorterid = this.sorterid;
		
		/*Sorts for the day*/
		let query = this.sortsForTheDay.sortsForTheDay_CurrentValue;
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', },
											   body: JSON.stringify({ query, variables: { startTime, goalVal, sorterid } })
		}).then(r => r.json())
		.then(data => { this.setState({ sorts: data.data.getUSSDataForLastXMins.sorts,
								    	isLoading:false}); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ sorts: 0,
						    isLoading:false
						  }); 
		});
		/*End of Sorts for the day*/
	}
	
	getCurrentPercentage() {
		let startTime = this.startTime;
		let goalVal = this.goalVal;
		let sorterid = this.sorterid;
		/*Sorts percentage for the day*/
		let query = this.sortsForTheDay.sortsForTheDay_CurrentPercentage
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', },
											   body: JSON.stringify({ query, variables: { startTime, goalVal, sorterid } })
		}).then(r => r.json())
		.then(data => { this.setState({ sortsPercent: data.data.getUSSDataForLastXMins.sortsPercent,
								    	isLoading:false}); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ sortsPercent: 0,
						    isLoading:false
						  }); 
		});
		/*End of Sorts for the day*/
	}
	
	getlastArray() {
		let startTime = this.startTime;
		let goalVal = this.goalVal;
		let sorterid = this.sorterid;
		/*Sorts Array*/
		let query = this.sortsForTheDay.sortsForTheDay_LastHours;
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', },
											   body: JSON.stringify({ query, variables: { startTime, goalVal, sorterid } })
		}).then(r => r.json())
		.then(data => { 
			let label = data.data.getUSSDataForLastXMins.inductsLastXDays == null ? [] : data.data.getUSSDataForLastXMins.inductsLastXDays.map(list => list.date.substring(6,8)+"/"+list.date.substring(4, 6)+"/"+list.date.substring(0, 4) );
		    let value = data.data.getUSSDataForLastXMins.inductsLastXDays == null ? [] : data.data.getUSSDataForLastXMins.inductsLastXDays.map(list => list.sorts);
		    this.setState({ label: label,
				   			value: value,
				   			isLoading:false
				   		  }); 
		}).catch((error) => {
			console.log(error);
			this.setState({ label: [],
	   						value: [],
						    isLoading:false
						  }); 
		});
		/*End of Sorts Array*/
	}
	
	render() {
				
		const { isColorBlind } = this.props;
			
		let guageBGColor = json.container.leftSegment.components[0].options.guageBGColor
		let fontColor = json.container.rightSegment.components[0].options.goalFontColor
		let graphBGColor = json.container.rightSegment.components[1].options.BGColor
		let chartLabel = json.container.rightSegment.components[1].options.label
	
		//Check For color blind and change the color
		if(isColorBlind) {
			guageBGColor = '#87871f'
			fontColor = '#1E90FF'
			graphBGColor = '#87871f'
		}
	
		if(this.state.isLoading){
			return (<RctCollapsibleCard	colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
										heading={<IntlMessages id="unitsorterDashbrd.sortsFrDay" />}
										fullBlock > 
							<Spinner />
					</RctCollapsibleCard>);
			} else {
				return (
						<RctCollapsibleCard colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
											heading={<IntlMessages id="unitsorterDashbrd.sortsFrDay" />}
											fullBlock >
							<div className="clearfix">
			                <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 float-left">
			                    <div className="d-flex">
			                        <div className="col-md-4 col-xl-4 col-sm-4 col-ls-4">
									<div className="circulararea">
			                        	<CircularProgressbar percentage={this.state.sortsPercent}
			                        						 text={`${this.state.sortsPercent}%`}
			                        						 backgroundPadding={10}
			                        						 styles={{ path: { stroke:  guageBGColor, strokeLinecap: 'butt' },
			                        							 	   text: { fill: '#121212', fontSize: '25px', textAnchor: "middle", dominantBaseline: "middle"},
			                        							 	   trail: { stroke: '#d7d7d7' },
			                        							 	   background: { fill: '#fffff' }
			                        						 }}
			                        	/>
										</div>
			                        </div>
			                        <div className="col-md-8 col-xl-8 col-sm-8 col-ls-8">
			                            <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 text-center">
			                                <span className="counter-point">
												<strong>&nbsp; <NumberClass  number={this.state.sorts} />  / &nbsp;
													<span style={{color: fontColor}}><NumberClass  number={this.props.goal} /></span></strong>
			                                </span>
			                            </div>
			                            <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12">
										<div className="lastdays-text">{<IntlMessages id="unitsorterDashbrd.lastXdays" />}</div>
			                                <div className="induct-line-bar">
											<TinyAreaChart chartdata={this.state.value}
					                     		   		   labels={this.state.label}
			                                    		   backgroundColor={hexToRgbA(ChartConfig.color.primary, 0.1)}
			                                    		   borderColor={graphBGColor}
			                                    		   lineTension="0"
			                                    		   height={130}
			                                    		   gradient />
														   </div>
			                            </div>
			                        </div>
			                    </div>
			                </div>
			            </div>
			        </RctCollapsibleCard>
				);
			}
	}
}


// map state to props
// Here we can fetch the value of isColorBlind as props
const mapStateToProps = ({ settings }) => {
	const { isColorBlind ,locale} = settings;
	console.log("isColorBlind value inside mapstateToProps -- "+ isColorBlind);
	return { isColorBlind,locale };
};

export default withRouter(connect(mapStateToProps)(SortsForTheDay));